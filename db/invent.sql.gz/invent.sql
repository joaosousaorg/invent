-- Adminer 4.8.1 MySQL 5.5.5-10.3.31-MariaDB-0ubuntu0.20.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `comp`;
CREATE TABLE `comp` (
  `id_comp` int(10) NOT NULL AUTO_INCREMENT,
  `marca` varchar(10) DEFAULT NULL,
  `modelo` varchar(20) DEFAULT NULL,
  `so` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_comp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `comp` (`id_comp`, `marca`, `modelo`, `so`) VALUES
(12,	'Apple',	'Macbook',	'MacOS'),
(14,	'Samsung',	'Galaxy',	'Windows 11 Pro'),
(15,	'Asus',	'Zenbook 14',	'Windows 11 Pro'),
(22,	'HP',	'HPPEPE3',	'Linux'),
(26,	'Lenovo',	'IdeaPad Flex 5',	'Windows 11 Home');

DROP TABLE IF EXISTS `comp_abat`;
CREATE TABLE `comp_abat` (
  `id_abat` int(11) NOT NULL AUTO_INCREMENT,
  `id_comp` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_abat`),
  KEY `id_comp` (`id_comp`),
  CONSTRAINT `comp_abat_ibfk_1` FOREIGN KEY (`id_comp`) REFERENCES `comp` (`id_comp`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `comp_abat` (`id_abat`, `id_comp`) VALUES
(12,	14),
(10,	15);

DROP TABLE IF EXISTS `software`;
CREATE TABLE `software` (
  `id_software` int(11) NOT NULL AUTO_INCREMENT,
  `id_comp` int(10) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `versao` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_software`),
  KEY `id_comp` (`id_comp`),
  CONSTRAINT `software_ibfk_4` FOREIGN KEY (`id_comp`) REFERENCES `comp` (`id_comp`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `software` (`id_software`, `id_comp`, `nome`, `versao`) VALUES
(14,	12,	'Safari',	'14.0'),
(22,	14,	'Google Chrome',	'96.0'),
(23,	15,	'Firefox',	'94.0');

-- 2021-11-27 17:02:53
